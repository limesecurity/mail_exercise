<?php
include 'dbsetting.php';

$select = $_REQUEST['select'];
$recvmail = $_REQUEST['recvmail'];

$host_name = $_REQUEST['host_name'];
$mac = $_REQUEST['mac'];

$remote_ip = $_SERVER['REMOTE_ADDR'];
$date=date("Y-m-d H:i:s");

$sql="insert exec_file (ip, mail, host_name, mac, date, kinds) VALUES('$remote_ip','$recvmail', '$host_name', '$mac', '$date', '$select')";
mysql_query($sql,$conn);
?>

