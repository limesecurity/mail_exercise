<?
include 'dbsetting.php';

$recvmail = $_REQUEST['recvmail'];
$select = $_REQUEST['select'];
$gubun = $_REQUEST['gubun'];

$name = $_POST['name'];
$mail = $_POST['mail'];
$phone = $_POST['phone'];
$remote_ip = $_SERVER['REMOTE_ADDR'];
$data=date("Y-m-d H:i:s");

$sql="insert entry_data (IP, RECVMAIL, NAME, PHONE, MAIL, DATE, KINDS, gubun) VALUES('$remote_ip','$recvmail','$name','$phone','$mail','$data', '$select', '$gubun')";
	
mysql_query($sql,$conn);

//Header("Location: /notice/message.html"); 
?>
<html>
<meta http-equiv="refresh" content="0; url=/notice/message.html"></meta>
</html>
