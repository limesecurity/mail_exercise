<?
include 'dbsetting.php';

$recvmail = $_REQUEST['recvmail'];
$select = $_REQUEST['select'];

$remote_ip = $_SERVER['REMOTE_ADDR'];
$data=date("Y-m-d H:i:s");

$sql="insert click_link (MAIL, IP, DATE, KINDS) VALUES('$recvmail', '$remote_ip', '$data', '$select')";
mysql_query($sql,$conn);
?>

<html>
<meta http-equiv="refresh" content="0; url=/<?=$select?>/entry.php?recvmail=<?=$recvmail?>&select=<?=$select?>"></meta>
</html>


