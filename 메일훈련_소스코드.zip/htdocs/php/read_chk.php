<?php
include 'dbsetting.php';

$recvmail = $_REQUEST['recvmail'];
$select = $_REQUEST['select'];

$remote_ip = $_SERVER['REMOTE_ADDR'];
$date=date("Y-m-d H:i:s");

$sql="insert read_mail (MAIL, IP, DATE, KINDS) VALUES('$recvmail', '$remote_ip', '$date', '$select')";
mysql_query($sql,$conn);
?>

