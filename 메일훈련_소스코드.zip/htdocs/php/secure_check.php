<?php
	include 'dbsetting.php';

	$recvmail = $_REQUEST['recvmail'];
	$select = $_REQUEST['select'];

	$query = "select mail from exec_file where mail='$recvmail' and kinds='$select'";

	//echo($query."<br>");

	$sql_result = mysql_query($query);

	$row = mysql_fetch_array($sql_result);

	//echo(count($row)."<br>");
	//echo($row['mail'].'<br>');

	if ( $row['mail'] == $recvmail ) {
		echo("true");
	} else {
		echo("false");
	}
?>