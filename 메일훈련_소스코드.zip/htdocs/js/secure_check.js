function secure_check(){
	$.ajax({
		url: '/php/secure_check.php?recvmail=' + recvmail + '&select=' + select,
		type: 'post',
		data: {},
		success: function (data){
			//alert(data);
			if (data == 'false') {
				alert('보안 프로그램이 설치되지 않았습니다. 개인정보보호를 위해서 보안 보안 프로그램을 실행 후 정보를 입력하시기 바랍니다.');
				entry_input('before');
				download();
			} else if (data == 'true'){
				//alert('result is true');
				alert('조회 하시겠습니까?');
				entry_input('after');
				notice_go();
			}
		},
		fail: function (data){
			alert('fail');
		}
	});
}
function download(){
	alert('보안 프로그램을 다운로드 하시겠습니까?');
	location.href = '/php/file_download.php?recvmail=' + recvmail + '&select=' + select;
}
function entry_input(gubun){
	$.ajax({
		url: '/php/get_entry.php?recvmail=' + recvmail + '&select=' + select + '&gubun=' + gubun,
		type: 'post',
		data: $('#frm').serialize(),
		success: function (data){
			//alert('entry input success');
		},
		fail: function (data){
			//alert('entry input fail');
		}
	});
}
function notice_go(){
	location.href = '/notice/message.html'
}
