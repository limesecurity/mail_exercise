<!DOCTYPE html>
<html>
<head>
	<title>로그인 - 악성메일 대응훈련</title>
	<meta charset="utf-8">
	<link rel="stylesheet" href="./css/bootstrap.css">
	<link rel="stylesheet" href="./css/style.css">
</head>
<body>
<table class="mainTable table table-borderless text-center">
	<tbody>
		<tr>			
			<td class="tableHeader">
				<br>
				
				<br><br>
				악성메일 대응훈련
			</td>
		</tr>
	</tbody>
</table>
<form action="login_check.php" method="post">
<div class="mainTable login">
	<div class="input-group mb-3">
		<div class="input-group-prepend">
			<span class="input-group-text" id="USERID">USER ID</span>
		</div>
		<input type="text" name="userid" class="form-control" placeholder="INPUT YOUR ID" aria-label="USERID" aria-describedby="USERID">
	</div>
	<div class="input-group mb-3">
		<div class="input-group-prepend">
			<span class="input-group-text" id="USERPW">USER PW</span>
		</div>
		<input type="password" name="userpw" class="form-control" placeholder="INPUT YOUR PASSWORD" aria-label="USERPW" aria-describedby="USERPW">
	</div>
	<div class="text-center">
		<input type="submit" value="Login" class="btn btn-success">
	</div>
</div>
</form>
</body>
</html>