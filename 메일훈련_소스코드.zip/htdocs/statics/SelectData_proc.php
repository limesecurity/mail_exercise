<?php
	session_start();

	# session check
	if($_SESSION['userid']==''){
			echo "<script>alert('Invalid Session');</script>";
			exit;
	}
	
	$select = $_REQUEST['select'];
	$_SESSION['dbname'] = $select;

	Header("Location: MainStatus.php?select=all&mode=view"); 
?>
