<?php
	session_start();

	# session check
	if($_SESSION['userid']==''){
			echo "<script>alert('Invalid Session');</script>";
			exit;
	}

	$dbname = $_SESSION['dbname'];
	$mail = $_REQUEST['mail'];
	$select = $_REQUEST['select'];
	$menu = $_REQUEST['menu'];
	$id = $_REQUEST['id'];

	$conn=mysql_connect("localhost","root","apmsetup");
	if(!$conn){
		die('Could not connect: '.mysql_errer());
	}
	
	mysql_select_db($dbname);

	switch ($menu) {
		case 'file':
			$table = 'exec_file';
			break;
		case 'readmail':
			$table = 'read_mail';
			break;
		case 'entry':
			$table = 'entry_data';
			break;
		case 'click':
			$table = 'click_link';
			break;
	}

	//$query = "delete from ".$table." where mail='".$mail."' and kinds='".$select."'";
	$query = "delete from ".$table." where id='".$id."'";

	$sql_result = mysql_query($query);

	//Header("Location: ExecStatus_admin.php?select=".$select); 
?>
<script>history.back(-1)</script>