<?php
	session_start();

	# session check
	if($_SESSION['userid']==''){
			echo "<script>alert('Invalid Session');</script>";
			exit;
	}
	$dbname = $_SESSION['dbname'];
	$select = $_REQUEST['select'];
	$mode = $_REQUEST['mode'];
	$sort = $_REQUEST['sort'];
	$current_menu = 'ResultSheet';

	$conn=mysql_connect("localhost","root","apmsetup");
	if(!$conn){
		die('Could not connect: '.mysql_errer());
	}
	mysql_select_db($dbname);

	$eventall_css = 'btn btn-outline-dark';
	$event1_css = 'btn btn-outline-dark';
	$event2_css = 'btn btn-outline-dark';
	$event3_css = 'btn btn-outline-dark';

	if ($select == "all") {
		$selquery = "";
		$eventall_css = 'btn btn-outline-primary';
	} else if ($select == "event1") {
		$selquery = " WHERE mail_cnt.kinds='event1'";
		$event1_css = 'btn btn-outline-primary';
	} else if ($select == "event2") {
		$selquery = " WHERE mail_cnt.kinds='event2'";
		$event2_css = 'btn btn-outline-primary';
	} else if ($select == "event3") {
		$selquery = " WHERE mail_cnt.kinds='event3'";
		$event3_css = 'btn btn-outline-primary';
	} else {
		$selquery = " WHERE mail_cnt.kinds='event99'";
		$event4_css = 'btn btn-outline-primary';
	}
?>
<!doctype html>
<html>
<head>
	<title>개인정보 입력 - 악성메일 대응훈련</title>
	<meta charset="utf-8">
	<link rel="stylesheet" href="./css/bootstrap.css">
	<link rel="stylesheet" href="./css/style.css">
</head>
<body>
<?
	include 'top_menu.php';
?>
<table class="mainTable table table-striped table-bordered table-hover table-sm text-center">
	<thead class="thead-dark">
		<tr>
			<th colspan=6>Total</th>
		</tr>
		<tr>
			<th scope="col" max-width="10%">No.</th>
			<th scope="col"><a href="ResultSheet.php?select=<?=$select?>&mode=view">대상자</a></th>
			<th scope="col"><a href="ResultSheet.php?select=<?=$select?>&mode=view&sort=1">메일열람</a></th>
			<th scope="col"><a href="ResultSheet.php?select=<?=$select?>&mode=view&sort=2">링크클릭</a></th>
			<th scope="col"><a href="ResultSheet.php?select=<?=$select?>&mode=view&sort=3">개인정보입력</a></th>
			<th scope="col"><a href="ResultSheet.php?select=<?=$select?>&mode=view&sort=4">파일실행</a></th>
		</tr>
	</thead>
	<tbody>
<?
	$full_query = 
"
SELECT DISTINCT mail_cnt.mail, readu.mail AS readmail, clicku.mail AS cilcklink, entryu.recvmail AS entrydata, execu.mail AS exefile
FROM mail_cnt
LEFT JOIN (SELECT DISTINCT mail FROM read_mail)readu ON mail_cnt.mail = readu.mail
LEFT JOIN (SELECT DISTINCT mail FROM click_link)clicku ON mail_cnt.mail = clicku.mail
LEFT JOIN (SELECT DISTINCT recvmail FROM entry_data)entryu ON mail_cnt.mail = entryu.recvmail
LEFT JOIN (SELECT DISTINCT mail FROM exec_file)execu ON mail_cnt.mail = execu.mail
";

	if ($sort == 1){
		$sortquery = ' ORDER BY readmail DESC';
	} else if($sort ==2){
		$sortquery = ' ORDER BY cilcklink DESC';
	} else if($sort ==3){
		$sortquery = ' ORDER BY entrydata DESC';
	} else if($sort ==4){
		$sortquery = ' ORDER BY exefile DESC';
	} else {
		$sortquery = '';
	}

	//echo($full_query.$sortquery);
	$result_get_indiv = mysql_query($full_query.$selquery.$sortquery);
	$no = 0;
	while($indiv_list = mysql_fetch_array($result_get_indiv)){
		$no = $no + 1;
		echo("<tr>");
		echo("<td>".$no."</td>");
		echo("<td>".$indiv_list['mail']."</td>");

		//메일열람
		if($indiv_list['readmail'] != NULL){
			echo("<td>O</td>");
		} else {
			echo("<td>X</td>");
		}

		//링크클릭
		if($indiv_list['cilcklink'] != NULL){
			echo("<td>O</td>");
		} else {
			echo("<td>X</td>");
		}

		//개인정보 입력
		if($indiv_list['entrydata'] != NULL){
			echo("<td>O</td>");
		} else {
			echo("<td>X</td>");
		}

		//파일실행
		if($indiv_list['exefile'] != NULL){
			echo("<td>O</td>");
		} else {
			echo("<td>X</td>");
		}
		echo("</tr>");
	}

?>
	</tbody>
</table>
<?
	include 'footer.php';
?>
</body>
</html>