﻿<?php
	session_start();
	if($_POST[userid]=='epffnsk')
	{
		if($_POST[userpw]=='epffnsk&2017')
		{
			header("Location: SelectData.php");
			$_SESSION['userid'] = 'lime';
		}
		else {
			echo "<script>window.alert('아이디/패스워드 확인');history.go(-1);</script>";
		}
	}
	else{
		echo "<script>window.alert('아이디/패스워드 확인');history.go(-1);</script>";
	}
?>

