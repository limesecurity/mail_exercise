﻿<?php
session_start();
session_destroy();
$_SESSION=array();
header("Location:login.php");
?>

<html>
<head>
	<meta charset="utf-8">
<title>LOGOUT</title>
</head>
<body>
	LOTOUT
</body>
