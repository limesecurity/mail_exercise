<?php
	session_start();

	# session check
	if($_SESSION['userid']==''){
			echo "<script>alert('Invalid Session');</script>";
			exit;
	}
	$dbname = $_SESSION['dbname'];
	$select = $_REQUEST['select'];
	$mode = $_REQUEST['mode'];
	$current_menu = 'MainStatus';

	$conn = mysql_connect("localhost","root","apmsetup");
	if(!$conn){
		die('Could not connect: '.mysql_errer());
	}
	
	mysql_select_db($dbname);

	$eventall_css = 'btn btn-outline-dark';
	$event1_css = 'btn btn-outline-dark';
	$event2_css = 'btn btn-outline-dark';
	$event3_css = 'btn btn-outline-dark';
	if ($select == "all") {
		$selquery = "";
		$eventall_css = 'btn btn-outline-primary';
	} else if ($select == "event1") {
		$selquery = " where kinds='event1'";
		$event1_css = 'btn btn-outline-primary';
	} else if ($select == "event2") {
		$selquery = " where kinds='event2'";
		$event2_css = 'btn btn-outline-primary';
	} else if ($select == "event3") {
		$selquery = " where kinds='event3'";
		$event3_css = 'btn btn-outline-primary';
	} else {
		$selquery = " where kinds='event99'";
		$event4_css = 'btn btn-outline-primary';
	}

	$query_release_count_mail = "SELECT COUNT(distinct mail) AS cnt FROM mail_cnt".$selquery;
	$query_read_mail = "SELECT COUNT(distinct mail) AS cnt FROM read_mail".$selquery;
	$query_execute = "SELECT COUNT(distinct mail) AS cnt FROM exec_file".$selquery;
	$query_click_entry = "SELECT COUNT(distinct mail) AS cnt FROM click_link".$selquery;
	$query_entry_data = "SELECT COUNT(distinct recvmail) AS cnt FROM entry_data".$selquery;

	$sql_result = mysql_fetch_array(mysql_query($query_release_count_mail));
	$total_release_count_mail = $sql_result['cnt'];

	# '0으로 나누기 에러' 방지
	if ($total_release_count_mail == 0) {
		$total_release_count_mail = 1;
	}
	
	$sql_result = mysql_fetch_array(mysql_query($query_read_mail));
	$infected_count_read_mail = $sql_result['cnt'];
	$infected_per_read_mail = number_format($infected_count_read_mail / $total_release_count_mail * 100, 2);
	
	$sql_result = mysql_fetch_array(mysql_query($query_execute));
	$infected_count_execute = $sql_result['cnt'];
	$infected_per_execute = number_format($infected_count_execute / $total_release_count_mail * 100, 2);
	
	$sql_result = mysql_fetch_array(mysql_query($query_click_entry));
	$infected_count_click_entry = $sql_result['cnt'];
	$infected_per_click_entry = number_format($infected_count_click_entry / $total_release_count_mail * 100, 2);
	
	$sql_result = mysql_fetch_array(mysql_query($query_entry_data));
	$infected_count_entry_data = $sql_result['cnt'];
	$infected_per_entry_data = number_format($infected_count_entry_data / $total_release_count_mail * 100, 2);
?>
<!doctype html>
<html>
<head>
	<title>메인 페이지 - 악성메일 대응훈련</title>
	<meta charset="utf-8">
	<link rel="stylesheet" href="./css/bootstrap.css">
	<link rel="stylesheet" href="./css/style.css">
</head>
<body>
<script language='javascript'>
	window.setTimeout('window.location.reload()', 30000);	//30초마다 새로고침
</script>
<?
	include 'top_menu.php';
?>
<table class="mainTable table table-striped table-bordered table-hover table-sm text-center">
	<thead class="thead-dark">
	<tr>
		<th colspan=2>Total</th>
	</tr>
		<tr>
			<th>메일 배포수</th>
			<th><?=$total_release_count_mail?></th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td>메일 열람</td>
			<td>비율</td>
		</tr>
		<tr>
			<td><?=$infected_count_read_mail?></td>
			<td><?=$infected_per_read_mail?></td>
		</tr>
		<tr>
			<td>첨부파일 실행</td>
			<td>비율</td>
		</tr>
		<tr>
			<td><?=$infected_count_execute?></td>
			<td><?=$infected_per_execute?></td>
		</tr>
		<tr>
			<td>첨부링크 클릭</td>
			<td>비율</td>
		</tr>
		<tr>
			<td><?=$infected_count_click_entry?></td>
			<td><?=$infected_per_click_entry?></td>
		</tr>
		<tr>
			<td>개인정보 입력</td>
			<td>비율</td>
		</tr>
		<tr>
			<td><?=$infected_count_entry_data?></td>
			<td><?=$infected_per_entry_data?></td>
		</tr>
	</tbody>
</table>
<table class="mainTable table table-borderless text-center">
	<tbody>
		<tr>
			<td colspan="6" class="thead-light">
				* 자동으로 30초마다 새로고침됩니다. *
			</td>
		</tr>
	</tbody>
</table>
<?
	include 'footer.php';
?>
</body>
</html>
