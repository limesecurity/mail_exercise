<?php
	session_start();

	# session check
	if($_SESSION['userid']==''){
			echo "<script>alert('Invalid Session');</script>";
			exit;
	}
	$dbname = $_SESSION['dbname'];
	$select = $_REQUEST['select'];
	$mode = $_REQUEST['mode'];
	$current_menu = 'LinkClickStatus';

	$conn=mysql_connect("localhost","root","apmsetup");
	if(!$conn){
		die('Could not connect: '.mysql_errer());
	}

	mysql_select_db($dbname);

	$eventall_css = 'btn btn-outline-dark';
	$event1_css = 'btn btn-outline-dark';
	$event2_css = 'btn btn-outline-dark';
	$event3_css = 'btn btn-outline-dark';
	if ($select == "all") {
		$selquery = "";
		$eventall_css = 'btn btn-outline-primary';
	} else if ($select == "event1") {
		$selquery = " where kinds='event1'";
		$event1_css = 'btn btn-outline-primary';
	} else if ($select == "event2") {
		$selquery = " where kinds='event2'";
		$event2_css = 'btn btn-outline-primary';
	} else if ($select == "event3") {
		$selquery = " where kinds='event3'";
		$event3_css = 'btn btn-outline-primary';
	} else {
		$selquery = " where kinds='event99'";
		$event4_css = 'btn btn-outline-primary';
	}

	$query = "select * from click_link".$selquery." order by date desc";

	$sql_result = mysql_query($query);
?>
<!doctype html>
<html>
<head>
	<title>첨부링크 클릭 - 악성메일 대응훈련</title>
	<meta charset="utf-8">
	<link rel="stylesheet" href="./css/bootstrap.css">
	<link rel="stylesheet" href="./css/style.css">
</head>
<body>
<?
	include 'top_menu.php';
?>
<table class="mainTable table table-striped table-bordered table-hover table-sm text-center">
	<thead class="thead-dark">
<?
	if ($mode == 'view') {
?>
		<th colspan=4>Total</th>
<?
	} else if ($mode == 'delete'){
?>
		<th colspan=5>Total</th>
<?
	}
?>
		<tr>
			<th>메일주소</th>
			<th>아이피</th>
			<th>클릭시간</th>
			<th>종류</th>
<?
	if ($mode == 'delete'){
?>
		<th scope="col">삭제</th>
<?
	}
?>
		</tr>
	</thead>
	<tbody>
<?
	while($row = mysql_fetch_array($sql_result)){
?>
		<tr>
			<td><?=$row["mail"]?></td>
			<td><?=$row["ip"]?></td>
			<td><?=$row["date"]?></td>
			<td><?=$row["kinds"]?></td>
<?
		if ($mode == 'delete'){
?>
		<td><a href='del_column.php?menu=click&id=<?=$row["id"]?>'>DEL</a></td>
<?
		}
?>
		</tr>
<?
	}
?>
	</tbody>
</table>

<?
	include 'footer.php';
?>
</body>
</html>