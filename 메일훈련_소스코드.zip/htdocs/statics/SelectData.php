<?php
	session_start();

	# session check
	if($_SESSION['userid']==''){
			echo "<script>alert('Invalid Session');</script>";
			exit;
	}

	$conn=mysql_connect("localhost","root","apmsetup");
	if(!$conn){
		die('Could not connect: '.mysql_errer());
	}

?>
<!doctype html>
<html>
<head>
	<title>메인 페이지 - 악성메일 대응훈련</title>
	<meta charset="utf-8">
	<link rel="stylesheet" href="./css/bootstrap.css">
	<link rel="stylesheet" href="./css/style.css">
</head>
<body>

<table class="mainTable table table-borderless text-center">
	<tbody>
		<tr>
			<td colspan="3" class="tableHeader">
				악성메일 대응훈련
			</td>
		</tr>
		<tr>
			<td colspan="2"><br><br><br><br><br></td>
		</tr>
		<tr>
<?
	$query = "show databases";

	$sql_result = mysql_query($query);

	while($row = mysql_fetch_array($sql_result)){
		$dbname = $row['Database'];
		//echo($dbname);
		if($dbname != 'information_schema' and $dbname != 'mysql' and $dbname != 'phpmyadmin'){
			if($_SESSION['dbname'] == $dbname){
				echo('<td><a class="btn btn-outline-primary" href="SelectData_proc.php?select='.$dbname.'">'.$dbname.'</a></td>');
				echo("\n");
			} else {
				echo('<td><a class="btn btn-outline-dark" href="SelectData_proc.php?select='.$dbname.'">'.$dbname.'</a></td>');
				echo("\n");
			}
		}
	}
?>
		</tr>
	</tbody>
</table>
</body>
</html>
