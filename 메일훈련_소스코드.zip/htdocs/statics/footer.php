<?php
	session_start();
?>
<div align="center">
<table>
	<tr height="50">
		<td> 이메일 대응훈련 세트 통계 페이지</td>
	</tr>
</table>
</div>