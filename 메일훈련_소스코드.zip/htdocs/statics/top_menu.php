<?php
	// include top menu
	session_start();

	# session check
	if($_SESSION['userid']==''){
			exit;
	}
	$css_mainstatus = 'btn btn-outline-dark';
	$css_readmailstatus = 'btn btn-outline-dark';
	$css_linkclickstatus = 'btn btn-outline-dark';
	$css_getentrystatus = 'btn btn-outline-dark';
	$css_execstatus = 'btn btn-outline-dark';
	$css_resultsheet = 'btn btn-outline-dark';

	switch ($current_menu) {
		case 'MainStatus':
			$css_mainstatus = 'btn btn-outline-primary';
			break;
		case 'ReadmailStatus':
			$css_readmailstatus = 'btn btn-outline-primary';
			break;
		case 'LinkClickStatus':
			$css_linkclickstatus = 'btn btn-outline-primary';
			break;
		case 'GetEntryStatus':
			$css_getentrystatus = 'btn btn-outline-primary';
			break;
		case 'ExecStatus':
			$css_execstatus = 'btn btn-outline-primary';
			break;
		case 'ResultSheet':
			$css_resultsheet = 'btn btn-outline-primary';
			break;
	}
?>
<table class="mainTable table table-borderless text-center">
	<tbody>
		<tr>
			<td colspan="6" class="tableHeader">
<?
	if ($mode=='view'){
?>
				악성메일 대응훈련 [열람 모드] <a href="SelectData.php">[<?=$dbname?>]</a>
<?
	} else if ($mode=='delete'){
?>
				악성메일 대응훈련 <span style="color:red">[삭제 모드]</span> <a href="SelectData.php">[<?=$dbname?>]</a>
<?
	}
?>
			</td>
		</tr>
		<tr>
			<td align="right" colspan="6">
<?
	if ($mode=='view'){
?>
				|&nbsp;<a href="<?=$current_menu?>.php?select=<?=$select?>&mode=delete">DELETE Mode</a>&nbsp;|&nbsp;<a href="logout.php">LOGOUT</a>&nbsp;|
<?
	} else if ($mode=='delete'){
?>
				|&nbsp;<a href="<?=$current_menu?>.php?select=<?=$select?>&mode=view">VIEW Mode</a>&nbsp;|&nbsp;<a href="logout.php">LOGOUT</a>&nbsp;|
<?
	}
?>
			</td>
		</tr>
		<tr>
			<td><a class="<?=$css_mainstatus?>" href="MainStatus.php?select=<?=$select?>&mode=<?=$mode?>">메인 통계</a></td>
			<td><a class="<?=$css_readmailstatus?>" href="ReadmailStatus.php?select=<?=$select?>&mode=<?=$mode?>">메일 열람</a></td>
			<td><a class="<?=$css_linkclickstatus?>" href="LinkClickStatus.php?select=<?=$select?>&mode=<?=$mode?>">첨부링크 클릭</a></td>
			<td><a class="<?=$css_getentrystatus?>" href="GetEntryStatus.php?select=<?=$select?>&mode=<?=$mode?>">개인정보 입력</a></td>
			<td><a class="<?=$css_execstatus?>" href="ExecStatus.php?select=<?=$select?>&mode=<?=$mode?>">첨부파일 실행</a></td>
			<td><a class="<?=$css_resultsheet?>" href="ResultSheet.php?select=<?=$select?>&mode=<?=$mode?>">개인별 현황</a></td>
		</tr>
	</tbody>
</table>
<table class="mainTable table table-borderless text-center">
	<tbody>
		<tr>
			<td><a class="<?=$eventall_css?>" href="<?=$current_menu?>.php?select=all&mode=<?=$mode?>">Total</td>
			<td><a class="<?=$event1_css?>" href="<?=$current_menu?>.php?select=event1&mode=<?=$mode?>">Event1</a></td>
			<td><a class="<?=$event2_css?>" href="<?=$current_menu?>.php?select=event2&mode=<?=$mode?>">Event2</a></td>
			<td><a class="<?=$event3_css?>" href="<?=$current_menu?>.php?select=event3&mode=<?=$mode?>">Event3</a></td>
		</tr>
	</tbody>
</table>