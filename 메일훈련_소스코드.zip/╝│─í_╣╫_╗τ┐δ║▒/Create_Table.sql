CREATE TABLE click_link (
	id int(10) unsigned NOT NULL AUTO_INCREMENT,
	ip varchar(20) NULL,
	mail varchar(40) NULL,
	date varchar(20) NULL,
	kinds varchar(20) NULL,
	PRIMARY KEY (id)
);

CREATE TABLE entry_data (
	id int(10) unsigned NOT NULL AUTO_INCREMENT,
	ip varchar(20) NULL,
	name varchar(30) NULL,
	phone varchar(20) NULL,
	mail varchar(40) NULL,
	date varchar(20) NULL,
	kinds varchar(20) NULL,
	recvmail varchar(20) NULL,
	PRIMARY KEY (id)
);

CREATE TABLE exec_file (
	id int(10) unsigned NOT NULL AUTO_INCREMENT,
	ip varchar(20) NULL,
	mail varchar(40) NULL,
	host_name varchar(30) NULL,
	mac varchar(30) NULL,
	date varchar(20) NULL,
	kinds varchar(20) NULL,
	PRIMARY KEY (id)
);

CREATE TABLE read_mail (
	id int(10) unsigned NOT NULL AUTO_INCREMENT,
	ip varchar(20) NULL,
	mail varchar(40) NULL,
	date varchar(20) NULL,
	kinds varchar(20) NULL,
	PRIMARY KEY (id)
);

CREATE TABLE mail_cnt (
	id int(10) unsigned NOT NULL AUTO_INCREMENT,
	mail varchar(40) NULL,
	kinds varchar(20) NULL,
	PRIMARY KEY (id)
);