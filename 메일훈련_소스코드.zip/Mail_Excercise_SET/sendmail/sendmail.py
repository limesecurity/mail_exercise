#-*- coding: utf-8 -*-
'''
FileName : sendmail.py
Creator : eli_ez3r
Company : LIME Security
'''
import smtplib, time, sys, os
import pymysql.cursors
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders

## 전역 변수 설정
# 설정파일
setting_file = '../setting.ini'

# 전역 변수들은 설정파일을 읽어서 세팅 하므로 가능한 하드 코딩하지 말고 설정파일에서 변경할 것
# 전역 변수 목록 (Don't change)
event = ''						# 이벤트 구분 (= 훈련 회차 구분)
target_email_file = ''			# 수신자 이메일 목록
mail_title = ''					# 메일 제목
mail_content_html = ''			# 메일 본문
sender_email = ''				# 발신자 이메일 주소
attachfile = ''					# 첨부 파일
mail_server_ip = 'localhost'	# smtp 서버 주소
mail_server_port = '25'			# smtp 서버 포트
dbname = ''						# Database 이름 (= 고객사 구분)
db_ip = ''
db_port = ''
db_id = ''
db_pwd = ''

## 설정파일을 읽어서 전역변수를 세팅한다
f = open(setting_file, 'r', encoding='utf-8')
lines = f.readlines()
f.close()
for line in lines:
	key = line.split('=')[0].strip()
	if key == 'database':
		dbname = line.split('"')[1]
	elif key == 'event_name':
		event = line.split('"')[1]
	elif key == 'target_email_file':
		target_email_file = '../' + line.split('"')[1]
	elif key == 'mail_title':
		mail_title = line.split('"')[1]
	elif key == 'mail_content_html':
		mail_content_html = './mail_content/' + line.split('"')[1]
	elif key == 'sender_email':
		sender_email = line.split('"')[1]
	elif key == 'filepath':
		attachfile = line.split('"')[1]
	elif key == 'database':
		dbname = line.split('"')[1]
	elif key == 'server_ip':
		db_ip = line.split('"')[1]
	elif key == 'server_port':
		db_port = int(line.split('"')[1])
	elif key == 'userid':
		db_id = line.split('"')[1]
	elif key == 'password':
		db_pwd = line.split('"')[1]
## 전역 변수 설정 끝

def sendEmail(fromEmail, toEmail, titleEmail, content, attfile):
	outer = MIMEBase('multipart', 'mixed') 
	outer['Subject'] = titleEmail
	outer['From'] = fromEmail
	outer['To'] = toEmail
	outer.preamble = 'This is a multi-part message in MIME format.\n\n' 
	outer.epilogue = ''	# 이렇게 하면 멀티파트 경계 다음에 줄바꿈 코드가 삽입 됨

	msg = MIMEText(content, 'html', _charset='utf-8')
	outer.attach(msg)
	
	# 파일 첨부, attfile='' 면 스킵
	if attfile != '':
		part = MIMEBase('application', 'octet-stream')
		part.set_payload(open(attfile, 'rb').read())
		encoders.encode_base64(part)
		part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(attfile))
		outer.attach(part)

	s = smtplib.SMTP('localhost', '25')
	s.login('lime', 'lime')
	s.sendmail(fromEmail, toEmail, outer.as_string())
	s.quit()

def sendQuery(mail):
	conn = pymysql.connect(host=db_ip, port=db_port, user=db_id, password=db_pwd, db=dbname, charset='utf8')

	try:
		with conn.cursor() as cursor:
			sql = "insert mail_cnt (mail, kinds) values(%s, %s)"
			cursor.execute(sql, (mail, event))
			conn.commit()
	except Exception as e:
		print(e)
	finally:
		conn.close()

def main():
	f = open(mail_content_html, 'r', encoding='utf-8')
	mailtext = f.read()
	f.close()

	f = open(target_email_file, 'r', encoding='utf-8')
	mlines = f.readlines()
	f.close()
	cnt = 0
	for line in mlines:
		# 주석 처리(#)된 이메일은 스킵한다
		if line[0:1] == '#':
			continue
		toEmail = line.strip().split(', ')[0]
		toName = line.strip().split(', ')[1]

		# 메일 본문에 이메일주소, 이름를 입력한다
		content = mailtext.replace('<mailaddress>', toEmail).replace('<mailname>', toName)

		if attachfile != '':
			filepath = attachfile
		else:
			filepath = ''

		# 메일 발송
		try:
			sendEmail(sender_email, toEmail, mail_title, content, filepath)
			pass
		except Exception as e:
			print('[*] Fail : ' + toEmail)
			print(e)
		else:
			print('[*] Success : ' + toEmail)
			cnt += 1
		
		sendQuery(toEmail)
		time.sleep(0.5) # server 과부화 방지

	print("Total Send Mail Count : {0}".format(cnt))


if __name__ == "__main__":
	main()
	exit()
