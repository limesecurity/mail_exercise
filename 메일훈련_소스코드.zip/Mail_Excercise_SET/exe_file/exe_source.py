#-*- coding:utf-8 -*-
import sys, os, requests
import io
import subprocess

# make_exe_sub.py 파일에서 URL, mail 를 setting.ini 파알에 맞게 수정하여 메일주소별 소스를 생성함

# Don't change
URL = '<exe_recode_url>'
mail = '<mailaddress>'
host = 'N/A'
mac = 'N/A'

# 맥주소와 호스트네임을 가져온다
# 리턴 형식은 다음과 같다. 연결된 인터페이스가 한 개인경우 0까지만, 복수인경우 개수만큼 반환)
# {'host':'sample-pc', 0:'AB-AB-AB-AB', 1:'CB-CB-CB-CB, ...}
def getHostInfo():
	arrinfo = {}
	isdevice = 0
	mk = 0
	if sys.platform == 'win32':
		try:
			cmdarg = "ipconfig /all"
			res = subprocess.Popen(cmdarg.split(), stdout=subprocess.PIPE, stderr=subprocess.PIPE)

			# 윈도우 커맨드의 출력값(stdout) 인코딩 형식이 한글(cpc949) 이므로 전달받을 때 인코딩 형식을 euc-kr로 지정
			for line in io.TextIOWrapper(res.stdout, encoding='euc-kr'):
				#print(line.lstrip().strip())
				if line.lstrip().startswith('호스트'):
					host = line.split(':')[1].strip()
					arrinfo["host"] = host
				else:
					if line.lstrip().startswith('터널'):
						isdevice = 0
					if line.lstrip().startswith('이더넷'):
						isdevice = 1
					if line.lstrip().startswith('무선'):
						isdevice = 1
					if isdevice == 1:
						if line.lstrip().startswith('미디어 상태'):
							desc = line.split(':')[1].strip()
							if desc == '미디어 연결 끊김':
								isdevice = 0
						if line.lstrip().startswith('설명'):
							desc = line.split(':')[1].strip()
							if desc.lstrip().startswith('bluetooth'):
								isdevice = 0
						if line.lstrip().startswith('물리적'):
							mac = line.split(':')[1].strip()
							arrinfo[mk] = mac
							isdevice = 0
							mk += 1
		except Exception as e:
			print(e)
			pass
	return arrinfo

def URL_con(URL, mail, host, mac):
	data = {}
	data['recvmail'] = mail
	data['host_name'] = host
	data['mac'] = mac
	session = requests.Session()
	session.verify = False
	session.post(URL, data=data)
	return True

## Main Start ##
ret = getHostInfo()
if 'host' in ret:
	host = ret['host']
if 0 in ret:
	mac = ret[0]

try:
	URL_con(URL, mail, host, mac)
except Exception as e:
	print(e)

print('Host Name: ' + host)
print('MAC Adress: ' + mac)
sys.exit()
