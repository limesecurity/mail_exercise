#-*- coding:utf-8 -*-
import sys, os, io
import time
import subprocess
import shutil

## 전역 변수 설정
# 설정 파일
setting_file = '../setting.ini'

# 설정 파일을 읽어서 전역 변수 세팅
f = open(setting_file, 'r', encoding='utf-8')
lines = f.readlines()
f.close()
for line in lines:
	key = line.split('=')[0].strip()
	if key == 'event_name':
		event = line.split('"')[1]
	elif key == 'target_email_file':
		target_email_file = '../' + line.split('"')[1]
	elif key == 'exeSource':
		code_file = line.split('"')[1]
	elif key == 'exe_recode_url':
		URL = line.split('"')[1]

# 실형 통계 기록 URL에 event 구분자 세팅
URL = URL + '?select='+ event

# 메일 주소 목록 읽기
f = open(target_email_file, 'r', encoding='utf-8')
mails = f.readlines()
f.close()

# exe_source.py 읽기
f = open(code_file, 'r', encoding='utf-8')
src_code = f.read()
f.close()

# 이벤트 디렉토리가 없으면 생성 후 이벤트 디렉토리로 이동
if not os.path.isdir(event):
	os.mkdir(event)
	os.chdir(event)

cnt = 0
for line in mails:
	line = line.strip().split(', ')[0]

	# 주석 처리(#)된 이메일은 스킵한다
	if line[0:1] == '#':
		continue

	cnt += 1
	print('[*] No: ' + str(cnt)) 

	# mail address 별로 디렉토리 생성
	print('[*] mkdir : ' + line)
	try:
		os.popen('mkdir ' + line)
	except Exception as e:
		print('[*] error: ' + line)
		print(e)
		print('\n')
		continue
	# 디렉토리 생성이 완료될 때가지 최대 2초를 기다린다
	n = 0.1
	while not os.path.isdir(line):
		time.sleep(n)
		n = n + 0.1
		if n > 2:
			print('directory making timeout')
			exit()
			#break

	# mail address 별로 소스 코드 생성
	mod_code = src_code.replace('<mailaddress>', line).replace('<exe_recode_url>', URL)
	fname = './'+line+'/'+line+'.py'
	print('[*] make source : ' + fname)
	try:
		# 소스 코드를 write
		f = open(fname, 'w', encoding='utf-8')
		f.write(mod_code)
	except Exception as e:
		print('[*] error: ' + line)
		print(e)
		print('\n')
	finally:
		f.close()

	# pyinstaller 실행
	print('[*] make exe (pyinstaller) : ' + line + '/check.exe\n')
	os.chdir('.\\' + line)
	try:
		cmdarg = 'pyinstaller -F -n check.exe ' + line + '.py'
		proc = subprocess.Popen(cmdarg.split(), stdout=subprocess.PIPE, stderr=subprocess.PIPE)

		# 이거 왜 출력 안되지? --> 이건 나중에 해결할 것
		# 여기 for문을 삭제하면 pyinstaller 가 실행 완료되기 전에 다음 단계가 진행되서 오류가 발생함
		for rline in io.TextIOWrapper(proc.stdout, encoding='euc-kr'):
			print(rline.strip())
	
		try:
			shutil.copy('./dist/check.exe', './')
			os.remove('check.exe.spec')
			shutil.rmtree('dist')
			shutil.rmtree('build')
		except Exception as e:
			print('[*] Error : Can \'t delete tmp file.')
			print(e)
			print('\n')

	except Exception as e:
		print('[*] Error in pyinstaller : ' + line)
		print(e)
	finally:
		proc.stdout.close()
		proc.terminate()
		os.chdir('..')

print('[*] Making exe file was Completed')
print('[*] Total count : ' + str(cnt))
