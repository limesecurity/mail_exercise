#-*- coding:utf-8 -*-
import sys, os, io
import time

# Setting File
ini_file = '../sendmail/setting.ini'


f = open(ini_file, 'r')
lines = f.readlines()
f.close()
for line in lines:
	line = line.strip()
	if line[0:10] == 'Event_name':
		event = line.split('"')[1]
	elif line[0:17] == 'target_email_file':
		target_email_file = '../sendmail/' + line.split('"')[1]
	elif line[0:9] == 'ExeSource':
		code_file = line.split('"')[1]

URL = 'http://121.135.219.82:8899/'+ event +'/php/file.php'

f = open(target_email_file, 'r')
mails = f.readlines()
f.close()

# --

for line in mails:
	line = line.strip().split(', ')[0]
	#print(line)
	print('[*] mkdir ' + line)
	try:
		os.popen('mkdir ' + line)
	except Exception as e:
		print('[*] error: ' + line)
		print(e)
		print('\n')
	finally:
		pass

print('[*] Making dir has been completed\n')


# --



f = open(code_file, 'r', encoding='utf-8')
src_code = f.read()
f.close()

for line in mails:
	line = line.strip().split(', ')[0]
	mod_code = src_code.replace('<mailaddress>', line).replace('<exe_recode_url>', URL)

	fname = './'+line+'/'+line+'.py'
	print('[*] make soruce : ' + fname)
	
	try:
		f = open(fname, 'w', encoding='utf-8')
		f.write(mod_code)
	except Exception as e:
		print('[*] error: ' + line)
		print(e)
		print('\n')
	finally:
		f.close()

print('[*] Making py file was Completed\n')
