#-*- coding: utf-8 -*-
'''
FileName : sendmail.py
Creator : eli_ez3r
Company : LIME Security
'''
import smtplib, time, sys, os
import pymysql.cursors
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders

### Global variable ###
#dbname = 'lime'						# 'EBS' 메일 훈련 DB
dbname = 'kised'						# 'kised' 메일 훈련 DB
event = 'event1'						# 동일 고객사에 대한 훈련의 회차를 구분할 수 있는 구분자
mail_title = '[메일훈련] 테스트 시나리오1'
mail_content_html = './mail_content/kised_event1.html'
sender_email = 'event_master@limesec.com'
target_email_file = 'mailList.txt'
attachfile = ''							# 첨부파일, ''면 첨부하지 않음
#attachfile = 'check.exe'

def sendEmail(fromEmail, toEmail, titleEmail, content, attfile):

	outer = MIMEBase('multipart', 'mixed') 
	outer['Subject'] = titleEmail
	outer['From'] = fromEmail
	outer['To'] = toEmail
	outer.preamble = 'This is a multi-part message in MIME format.\n\n' 
	outer.epilogue = ''	# 이렇게 하면 멀티파트 경계 다음에 줄바꿈 코드가 삽입 됨

	msg = MIMEText(content, 'html', _charset='utf-8')
	outer.attach(msg)

	if attfile != '':
		part = MIMEBase('application', 'octet-stream')
		part.set_payload(open(attfile, 'rb').read())
		encoders.encode_base64(part)
		part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(attfile))
		outer.attach(part)

	s = smtplib.SMTP('localhost', '25')
	s.login('lime', 'lime')
	s.sendmail(fromEmail, toEmail, outer.as_string())
	s.quit()

def sendQuery(mail):
	conn = pymysql.connect(host='121.135.219.82', port=9988, user='root', password='apmsetup', db=dbname, charset='utf8')

	try:
		with conn.cursor() as cursor:
			sql = "insert mail_cnt (mail, kinds) values(%s, %s)"
			cursor.execute(sql, (mail, event))
			conn.commit()
	except Exception as e:
		print(e)
	finally:
		conn.close()

def main():
	f = open(mail_content_html, 'r')
	lines = f.readlines()
	f.close()
	mailtext = ''
	for line in lines:
		mailtext += line

	f = open(target_email_file, 'r')
	lines = ''
	lines = f.readlines()
	f.close()
	cnt = 0
	for toEmail in lines:
		toEmail = toEmail.strip()

		# 메일 본문 파일(mail_content_html)에서 목적지 이메일 키워드로 <mailaddress>를 사용해야 아래의 라인에서 replace 가 가능함
		content = mailtext.replace('<mailaddress>', toEmail)

		if attachfile != '':
			filepath = './exe_file/' + toEmail + '/' + attachfile
		else:
			filepath = ''

		try:
			sendEmail(sender_email, toEmail, mail_title, content, filepath)
		except Exception as e:
			print('[*] Fail to : ' + toEmail)
			print(e)
		else:
			print('[*] Success to : ' + toEmail)
			cnt += 1
		
		sendQuery(toEmail)
		time.sleep(0.5) # server 과부화 방지

	print("Total Send Mail Count : {0}".format(cnt))


if __name__ == "__main__":

	main()

