#-*- coding:utf-8 -*-
import sys, os, io
import time

f = open('../sendmail/mailList.txt', 'r')
mails = f.readlines()
f.close()

for line in mails:
	line = line.strip().split(', ')[0]
	#print(line)
	print('[*] mkdir ' + line)
	try:
		os.popen('mkdir ' + line)
	except Exception as e:
		print('[*] error: ' + line)
		print(e)
		print('\n')
	finally:
		pass

print('[*] Making dir has been completed\n')




