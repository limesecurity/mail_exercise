#-*- coding: utf-8 -*-
'''
FileName : sendmail.py
Creator : eli_ez3r
Company : LIME Security
'''
import smtplib, time, sys
import pymysql.cursors
from email.mime.text import MIMEText
from email.mime.base import MIMEBase

def sendEmail(fromEmail, toEmail, titleEmail, content):

    outer = MIMEBase('multipart', 'mixed') 
    outer['Subject'] = titleEmail
    outer['From'] = fromEmail
    outer['To'] = toEmail
    outer.preamble = 'This is a multi-part message in MIME format.\n\n' 
    outer.epilogue = ''    # 이렇게 하면 멀티파트 경계 다음에 줄바꿈 코드가 삽입 됨

    msg = MIMEText(content, 'html', _charset='utf-8')
    outer.attach(msg)

    # 로컬 SMTP Server 사용
    s = smtplib.SMTP('localhost', 25)
    s.login('lime', 'lime')

    # 외부 SMTP Server 사용
    #s = smtplib.SMTP('192.168.10.124', 25)
    #s.login('lime', 'lime')

    s.sendmail(fromEmail, toEmail, outer.as_string())

    s.quit()

def sendQuery(mail, event):
    conn = pymysql.connect(host='121.135.219.82', port=9988, user='root', password='apmsetup', db='lime', charset='utf8')

    try:
        with conn.cursor() as cursor:
            sql = "insert mail_cnt (mail, kinds) values(%s, %s)"
            cursor.execute(sql, (mail, event))
            conn.commit()
    finally:
        conn.close()
def main(event):
    cnt = 0
    
    with open('C:\\Users\\aa\\Desktop\\sendmail\\mailList.txt', 'r') as f:
        lines = f.readlines()
        for line in lines:
            line = line.strip()
            if event == 'event1':
                titleEmail = "[메일훈련] 테스트"
                #titleEmail = "[악성코드 이메일 모의훈련] 사전 테스트1 이메일 발송"
                fromEmail = "event@vips.co.kr"
                content = event1_content(line)
            if event == 'event2':
                titleEmail = "[CGV] EBS 임직원 영화관람권 제공 이벤트 안내"
                #titleEmail = "[악성코드 이메일 모의훈련] 사전 테스트2 이메일 발송"
                fromEmail = "master@cgv.co.kr"
                content = event2_content(line)
            if event == 'event3':
                titleEmail = "미 발송 택배 이력 조회"
                fromEmail = "test@test.com"
                content = event3_content(line)
            sendEmail(fromEmail, line, titleEmail, content)
            sendQuery(line, event)
            cnt += 1
            print("[{0}]Success Send Mail To : {1}".format(cnt, line))
            time.sleep(0.5) # server 과부화 방지
    print("Total Send Mail Count : {0}".format(cnt))

def event1_content(mail):
    content = '''
    <!DOCTYPE html>
    <html lang="kr">
    <head>
    <meta charset="utf-8">
    </head>
    <body>
	메일훈련 테스트

    <a href="http://121.135.219.82:8899/event1/php/link_click_chk.php?recvmail='''
    content += mail
    content += '''	
        " target="_blank">
	<img src="http://121.135.219.82:8899/event1/mailImage.png" width="700px"></a>
    </body>
    </html>'''
    return content

def event2_content(mail):
    content = '''
    <!DOCTYPE html>
    <html lang="kr">
    <head>
    <title>EBS 임직원 대상 이벤트</title>
    <meta charset="utf-8">
    </head>
    <body>
    본 메일은 EBS 악성코드 이메일 모의훈련 사전 테스트로 정상 실행 여부 점검 목적으로 발송드립니다.<br>
    실행 절차 : '응모하러가기' 버튼 클릭 > 이름, 전화번호, 이메일 기입 > '응모하기' 버튼 클릭 > 훈련 안내 문구 실행 > 신고양식 다운로드<br>
    <br>
    비정상 실행 증상 및 기타 의견이 있으실 경우 아래 메일로 회신 주시면 훈련 진행 시 반영하도록 하겠습니다.<br>
    회신 이메일 : jwcha@ebs-it.co.kr<br>
    <br>
    훈련 개요<br>
    -   일시 : 5/13(월) ~ 5/17(금)<br>
    -   목적 : 최근 악성 이메일을 통한 개인정보가 누출된 사태를 모의 훈련을 통해 재현하여 사용자 인식제고 및 실제 상황 시 보안관리부서에 신고하여 신속하게 악성코드에 대한 초기 대응이 될 수 있도록 함<br>
    -   훈련 진행부서 : IT운영부 / 인프라운영팀(링네트/안랩)<br>
    -   신고 접수자 : 정책기획부 민병갑<br>
    <a href="http://121.135.219.82:8899/event2/php/link_click_chk.php?recvmail='''
    content += mail
    content += '''
    " target="_blank" id="submitEvent"><img src="http://121.135.219.82:8899/event2/mailImage.png" width="700px"></a>
    </body>
    </html>'''
    return content

def event3_content(mail):
    content = '''
		<!DOCTYPE html>
		<html lang="kr">
		<head>
		<title>미 발송 택배 이력 조회</title>
		<meta charset="utf-8">

		</head>
		<body>
		<div id="contentWrap">
   			<div id="eventImage"><img src="http://121.135.219.82:8899/event3/image.png" title="미 발송 택배 이력 조회 상세 이미지"></div><div id="eventForm">
      		<div class="formRow">
        		<a href="http://121.135.219.82:8899/php/down_chk.php?recvmail='''
    content += mail
    content +='''		 
		" target="_blank" id="submitEvent">택배서비스</a>
      		</div>
      		<div class="formRow">
         		<a href="http://121.135.219.82:8899/event3/php/link_click_chk.php?mail='''
    content += mail
    content +='''		 
		" target="_blank" id="submitEvent">조회신청</a>
      		</div>
   		</div>
   		<div class="footer">- Local/Global Delivery Tracking Service -</div>
		</div>
		</body>
		</html>'''
    return content

if __name__ == "__main__":
    if len(sys.argv) is 1:
        print("Usage : python {0} [Event Number]. \nex) python {0} event1\nEvent Value : event1, event2, event3".format(sys.argv[0]))
    else:
        main(sys.argv[1])
